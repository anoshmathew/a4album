A Pen created at CodePen.io. You can find this one at http://codepen.io/vsync/pen/upeBw.

 Photobox is the evolution, the next generation of gallery UI & UX code. It can do anything. It's super flexible.